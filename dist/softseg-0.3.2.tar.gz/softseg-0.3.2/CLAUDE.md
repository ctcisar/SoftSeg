# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Package Overview

SoftSeg is a Python package for **soft transcript-to-cell assignment** in spatial transcriptomics. Rather than making hard binary assignments, it assigns each transcript probabilistic confidence scores to one or more nearby cells, based on distance from cell segmentation mask contours. It also includes tools for downstream cell type annotation using a single-cell reference dataset.

## Install & Build

```bash
# Editable install for development
pip install -e .

# Build distributable
python -m build
```

Built with `hatchling`. Package source lives in `src/SoftSeg/`.

## Linting

**Run the linters in the default python environment (`/home/cecilia/miniconda3/bin/python`, 3.10) over anything you change, and fix what they report in your own code before saying you are done.** What is installed there: `flake8` 4.0.1, `pylint` 2.12.2, `black` 24.1.1, `isort`, `mypy` 0.942, `pyflakes` 3.0.1.

```bash
pyflakes src/SoftSeg/*.py                     # must stay clean
flake8 --max-line-length=88 src/SoftSeg/      # style; see below
```

- **`pyflakes` is the one that has to stay clean.** It catches the real defects — unused imports, undefined names, shadowing — and it is how the leftovers from a refactor get noticed. (`logging` and `TableModel` sat unused in `SupportFuncs.py` after the ome-zarr and shapes passes until it said so.)
- **The line length is 88, not flake8's default 79.** The code is written to black's width: checked at 79 the package reports ~900 findings, at 88 it reports a few dozen. There is no lint config in the repo, so the flag has to be passed. `--max-line-length=88` is the convention, not a preference to re-litigate.
- **Do not blanket-reformat with `black` or `isort`.** They would rewrite whole files and bury a real change in noise. Match their conventions when writing new code instead; `black` is here to be read, not run over the tree.
- **Fix findings in code you wrote, leave pre-existing ones alone — except E303.** E303 (too many blank lines) is fixed wherever it appears, pre-existing or not: removing a blank line changes nothing else, so it cannot bury a real change the way a reformat would. Check with `flake8 --max-line-length=88 --select=E303 src/SoftSeg/`, which should report nothing. Most of what is left otherwise is E501 in the older `evaluate_overlapping_regions` region of `SoftAssigner.py`; cleaning those up is its own task, not a rider on an unrelated change. E203 (whitespace before `:`) is what black itself produces and is conventionally ignored.
- `codedump.py` is scratch and not held to this.

## Key Files

- **`SoftAssigner.py`** — Core pipeline class. Handles the full soft-assignment workflow per field-of-view (FOV).
- **`CellTypeAssigner.py`** — Cell type annotation using a single-cell RNA-seq reference via scanpy. Takes its target either as an `adata` or as `sdata` + `table_name`, and `save_annotated_adata` writes the annotated result back as a table in the store.
- **`SpatialDataHelpers.py`** — The SpatialData layer. Everything lives on the `SpatialDataHelpers` class (nothing at module scope), in four labelled sections: (1) coordinate-system and store conventions (`STACK_3D_CS`, `SOFTSEG_ATTRS`, `_element_fov_cs`, `quiet_ome_zarr`, `open_store`), (2) the z-slice machinery `SoftAssigner` uses (slice resolution, the `snap_z`/`valid_z` policy), (3) masks → per-z-slice shapes (`masks_to_shapes`), (4) standalone 3D utilities (`select_zslice`, `aggregate_zslice_shapes`).
- **`__init__.py`** — Exposes `SpatialDataHelpers` and calls `quiet_ome_zarr()` once on import; see below.
- **`SupportFuncs.py`** — Utilities: KL divergence between anndata objects, `SegImagePlotter` (below), `NeighborPredictor`, `ParamSweeper`, `UnitTestWarper`, `DatasetFormatter`, `AssignmentComparer` and `LegacyRunLoader` (all below).
- **`scoring.py`** — The scoring methods: how a candidate assignment of transcripts to cells is judged. Registry, base class, the `"additive matrix"` method the package has always used, and a worked example of a second one.
- **`codedump.py`** — Scratch/experimental code; not part of the package API.
- **`test.py`** — Scratch plotting script; not a formal test suite.

### Reading a store is quiet

spatialdata writes a labels element without the image it would be a label *of*, so ome-zarr-py logs `no parent found for ...` every time it reads one ([spatialdata#400](https://github.com/scverse/spatialdata/issues/400)). A per-FOV store has hundreds of labels elements — 295 lines for one real dataset — so opening one buries the session in complaints about a layout this package uses on purpose.

`SpatialDataHelpers.quiet_ome_zarr()` drops those records, and `SoftSeg/__init__.py` calls it on import, so they are gone wherever a store is opened — by this package or by `spatialdata.read_zarr` the user calls themselves. The read paths (`SoftAssigner.sdata`, `SegImagePlotter`, `UnitTestWarper`, `softseg_to_spatialdata`) call it too, so the intent stays legible where the reading happens; it is idempotent, so the repeats cost nothing and no filter stacks up.

It is deliberately narrow: **only** that one message, and only on `ome_zarr.reader`, the logger that emits it. Silencing the whole logger — which three separate places used to do, two of them with `setLevel(ERROR)` — would also hide a real problem reading a store.

### Reading a store is lazy

`spatialdata.read_zarr` reads images, labels and points as dask, but shapes and tables in full. On one real store that is 9 GB of shapes and 11 GB of tables (7.5 GB of it one 38M-row `assigned_trs_*` table) before anything has been asked for. Two assigners open at once was enough to run the machine out of memory.

`SpatialDataHelpers.open_store(path)` is what every read path uses (`SoftAssigner.sdata`, `SegImagePlotter`, `UnitTestWarper`). It reads the lazy groups as usual. For `ON_DEMAND_GROUPS` (shapes, tables) it installs subclasses of spatialdata's own `Shapes`/`Tables` containers (`_OnDemand`). These know every name in the store from the start, so `in`, iteration, `keys()` and `len()` behave as though everything were loaded, and `sdata.tables[name]` reads that one element on first access. Opening the store above takes ~1s and 0.3 GB.

- **`loaded_only(sdata)`** — spatialdata's `write_element` and `delete_element_from_disk` both walk `.items()` over every element in passing. Without this context, every save would read the whole store. Inside it, `values()`/`items()` yield only what is in memory. `save_element` and `remove_element` wrap their spatialdata calls in it. Outside it, `values()`/`items()` keep dict semantics and read everything.
- **`release_element(sdata, name)`** — drops a loaded element that was read from the store and has not been replaced since, so it is re-read when next asked for. `get_cell_shapes` releases each FOV's shapes after reading them, so a run over every FOV does not end up holding all of them. Anything assigned in memory is never released, since it exists nowhere else.
- **`table_obs(sdata, name)`** — a table's `obs` alone, read from the obs group if the table is not loaded yet. `set_cell_types_from_table` uses it, so typing cells from `cxg` never reads its dense matrix (2.8 GB on the store above). `infer_cats` accepts a bare obs frame for the same reason, and `default_cxg_table_name` resolves which table without reading it.

`sdata["name"]`, `"name" in sdata` and `print(sdata)` go through spatialdata's `gen_elements` and so still read everything; `sdata.tables[...]`/`sdata.shapes[...]` are the ways in that do not. The containers depend on spatialdata internals (`spatialdata._core._elements`, `_io.io_table._read_table`, `_io.io_shapes._read_shapes`, `SpatialData._shapes`/`_tables`), written against 0.7. `DatasetFormatter.softseg_to_spatialdata` still uses a plain `read_zarr`, since the store it re-reads holds no shapes or tables.

## Architecture & Data Flow

### SoftAssigner

Initialized with a single argument, `sdata`: a `spatialdata.SpatialData` object or a path to a zarr store holding one. **It is both the input and the output** — no other paths are involved. Build it with the standard readers for your platform (`spatialdata_io.cosmx`, `xenium`, …), or with `SupportFuncs.DatasetFormatter.softseg_to_spatialdata` for a dataset that exists as the older per-FOV CSV/TIFF file set. It holds per FOV:
- `labels[f"{fov}_labels"]` — segmentation mask, 2D `(y, x)` or 3D `(z, y, x)`
- `points[f"{fov}_points"]` — transcript table (`x`, `y`, `global_z`, `gene`, `index`, plus the `z`/`global_x`/`global_y` the converter adds). Results are appended here as new columns.
- `shapes[f"{fov}_z{z}_shapes"]` — *(optional)* per-z-slice cell polygons
- `tables[...]` — cell-by-gene results and delta tallies

**Persistence.** Every element this class alters is saved back to the store it came from, via `save_element`. `SoftAssigner(sdata, save_to_disk=False)` turns that off wholesale — results still accumulate in the sdata in memory but nothing touches the store, for trying something out against real data without altering it. Saving is the default; a pooled run requires it, since a worker returns its results by saving its own element, and is refused otherwise. The per-call `save=False` on `set_transcripts`/`blur_fov`/`evaluate_overlapping_regions_single_fov` is the narrower version of the same thing, for deferring many successive writes into one. Rewriting an element in place is a `delete_element_from_disk` followed by `write_element` — zarr refuses to overwrite a path it is currently backing an element from — so the replacement must already be fully in memory (`set_transcripts` builds it through `.compute()`) before the delete. The pair is not atomic: an interruption between them leaves the element in memory only, and re-running the step rewrites it. An sdata with no store on disk (`is_backed()` false) is worked on purely in memory and never saved.

Transcript tables are read and written through `get_transcripts`/`set_transcripts`, which go directly to the points element's parquet. Columns holding python objects — the `{cell_id: score}` maps in `cell_ids` — are stored as their `str()` repr, since parquet has no type for them, and read back with `ast.literal_eval`.

**Removing a run.** `remove_results(assigned_col)` takes out everything one evaluation wrote, by its column name, and returns what it removed:

- the `assigned_col` and `{assigned_col}_type` transcript columns, a FOV at a time;
- the `assigned_trs_`/`seg_is_default_` region tables, each FOV's `{fov}_deltas_` table, and `cxg_resegmented_{col}`;
- the `attrs["scoring"]` entry.

`run_elements(assigned_col)` lists the same things without touching anything. It reads only schemas and element names. `og_cell`/`og_type` stay, as do `cell_ids` and the transcript columns themselves (`SHARED_COLUMNS`, which the method refuses to remove): they are the baseline every run is compared against, not one run's result. A cxg table written under a name of its own choosing is not found, since nothing records which column it came from. With `save=False` or `save_to_disk=False` the removal is in memory only; otherwise it deletes from the store and cannot be undone.

Progress is tracked by what the data carries, not by which files exist: `get_complete_fovs(column="cell_ids")` and `get_incomplete_fovs(...)` test for the column's presence in the points schema.

Accessors wrap the sdata layout: `remove_results`, `run_elements`, `get_mask`, `get_transcripts`, `set_transcripts`, `get_cell_shapes`, `get_fov_affine`, `get_dist_between_slices`, `valid_slices`, `transcript_slices`, `has_column`, `save_element`, `save_table`.

**Pipeline stages:**

1. **`blur_all_fovs(...)`** — Runs `blur_fov` across all incomplete FOVs using a multiprocessing `Pool` (`pool_size` parameter). For each FOV: reads mask + transcripts from the sdata, takes one polygon per cell per z-slice (reusing existing `{fov}_z{z}_shapes` elements when present, otherwise contouring the labels via `SpatialDataHelpers.masks_to_shapes`), computes signed distance from each transcript to the polygon on its own z-slice, applies a sigmoid decay function (`sigm()`) to convert distance to a confidence score. Adds a `cell_ids` column to the FOV's points element, storing `{cell_id: score}` dicts as strings, and saves it.

1b. *(Optional)* **Cell type labelling** — `get_scoring_matrix` (step 2) requires cell type labels on each cell. If no external cell type annotation is available, the package provides tools to generate one. `calculate_confident_threshold()` analyzes multiply-assigned transcripts to suggest a `min_thresh` value; this threshold can then be passed to `generate_cxg_table()` to produce a preliminary AnnData. `CellTypeAssigner` can then be used to cluster that AnnData against a paired single-cell RNA reference and label each cell with a cell type, producing the annotated AnnData needed as input to step 2.

2. **`get_scoring_matrix(...)`** — Builds a scoring matrix from an AnnData object and a dict of cell type categories (`cats`), used to score transcript-to-cell assignments in overlapping regions. `cats` takes either form: `{"column": ["type", ...]}` in full, or just `"column"` — the obs column holding the types, whose labels are then read off it (`infer_cats`). Called with no arguments at all, both are taken from the sdata: the table `generate_cxg_table` stored there (`default_cxg_table`, preferring `"cxg"`), and the one categorical obs column that is neither geometry nor an identifier. Ambiguity is refused rather than guessed — several candidate tables or columns raise and name what they found, so pass `table_name=` or `cats="column"` in that case.

QC bounds can be applied to the table before it is scored, which is what the pre-package notebooks did with `CellTypeAssigner.filter_cells`/`filter_genes` before handing the result over: `min_counts`/`max_counts` bound a cell's total transcript count, `min_genes` its number of distinct genes, and `min_cells` drops genes seen in too few of the *remaining* cells (cells first, then genes, matching the old order). `filter_for_scoring` does the work and agrees with `sc.pp.filter_cells`/`filter_genes` exactly; it never touches the stored table. Two consequences worth knowing: a dropped cell is absent from `cell_to_type`, so it is untyped and an overlapping region containing it is skipped unless `use_other_cells=True`; a dropped gene simply stops contributing to any score, exactly as a blank does. A cell type the bounds empty out is left out of the scoring matrix rather than becoming a row of NaN.

**Cell types are not the scoring method's to own.** `SoftAssigner.cell_to_type` is the `{cell id: cell type}` mapping the evaluation steps read, stored in the sdata as the `cell_to_type` table (`SoftAssigner.CELL_TYPE_TABLE`; `save=False` keeps it in memory) and read back from there on first access, so a store given types once can be picked up again without redoing it. Three ways in, none privileged:

- **`set_cell_types_from_table(column=None, table_name=None)`** — read a column of the cell-by-gene table, which is where `CellTypeAssigner` leaves its annotation and where anything that typed the cells elsewhere would put it. The column is inferred the same way `get_scoring_matrix` infers `cats` when it is not told, and naming one that is not there raises listing what is.
- **a scoring method**, as a side effect of building its reference — `AdditiveMatrixScoring` does, since it has the types in hand anyway.
- **assignment** — `assigner.cell_to_type = {...}` then `save_cell_to_type()`, for a mapping built some other way entirely.

All three go through `as_cell_to_type`, so ids and types are strings whichever way they arrived, and a cell with no type is **left out** rather than typed `"None"`. An untyped cell is one an overlapping region skips unless `use_other_cells`, and one the cell-type scoring methods score against the "other" row when it is compared (never, for a cell the QC dropped). `MISSING_TYPES` lists the spellings that count as absent, `"Unassigned"` among them. Pre-change code treated a `"None"`-labelled cell as typed — it had its own row and its regions were evaluated — so on the real store a `use_other_cells=False` run now differs from the pre-refactor package wherever such a cell was involved.

The two sources do not type the same cells, and the difference is not a bug: a scoring method types only the cells that survived its own QC filter (on one real store, 161,304 of the 489,444 the `celltypes` column names), which is exactly what makes a filtered-out cell untyped. Reading the column types every cell it names. Only the mapping is stored, never a scoring method's reference — resolving an overlapping region still needs that method prepared.

3. **`evaluate_all_overlapping_regions(...)`** — Resolves ambiguous transcript assignments in regions where multiple cells overlap. Runs `evaluate_overlapping_regions_single_fov` in parallel across FOVs (in batches of 100 to limit memory leakage). For each FOV: transcripts are first split into confident (single clear assignment above `min_thresh`) and unconfident (multiple candidate cells). Unconfident transcripts are grouped by their set of candidate cells; groups where all candidates share the same cell type, or where any candidate is untyped (unless `use_other_cells=True`), are skipped. For each remaining group, a range of soft-score thresholds is swept to generate candidate hard assignments, each scored via `score_tr_assignment` using the scoring matrix from step 2. An assignment only replaces the default (original mask) assignment if it exceeds the default score by a factor of `default_thresh` (default 5×). The best assignment is written to a new `assigned_col` column on the FOV's points element, alongside `og_cell`, `og_type` and `{assigned_col}_type`. All four name a cell or a cell type per transcript, and all four say "not assigned" the same way: `SoftAssigner.MISSING` (`pd.NA`) in a `"string"` column, built through `as_label_column`. That is what parquet hands back for any absent value however it went in, so a column reads back as it was written instead of changing type on the first reload, and an absent value costs a bit in the validity bitmap rather than a stored string. Stores written before this have the sentinel string `"None"` in the three tracking columns; `generate_cxg_table` and `ParamSweeper._normalize_missing` still treat that as absent, since left alone it reaches `int()` and raises. With `save_delta_tallies=True`, per-cell gained/lost/changed/final counts are stored as a `{fov}_deltas_{assigned_col}` table — one per FOV, so pooled workers each save their own element.

How each assignment was reached is kept alongside it, as two tables per run rather than per FOV: `assigned_trs_{assigned_col}` holds one row per (cell, transcript) pair, `seg_is_default_{assigned_col}` one row per ambiguous region and whether the original segmentation won it. Both carry a `fov` column and keep their content in `obs` on a zero-variable AnnData, since neither is a measurement over genes. `transcript_id` is an `int64`: as a float it read back as `997019.0`, and float64 cannot hold an id past 2\*\*53 exactly — it rounds to a neighbour silently, which for an identifier means naming the wrong transcript. Rows written before that read back as floats, so `_merge_region_rows` casts each part before concatenating them, not the result after, which would let one float part pull the integer rows up; the cast is strict, since a NaN in that column would mean the rows are not what the table is for. Because they span every FOV, a worker cannot save its own — several rewriting one element would leave only whichever finished last — so `evaluate_all_overlapping_regions` collects each FOV's rows (`defer_region_tables`) and merges them once, in the parent, after the pool has finished. Merging replaces a FOV's existing rows when `overwrite` is set and leaves them otherwise.

### Evaluating overlapping regions: the argument list

The thirteen knobs `evaluate_all_overlapping_regions` and `evaluate_overlapping_regions_single_fov` share used to be spelled out three times — both signatures and the positional `zip` the worker pool was built from — so adding one meant editing three lists and reordering one silently mis-bound every argument after it. They are one object now, **`RegionEvalParams`**, and the pool's `zip` carries it whole.

Both methods still take them as keywords (`**overrides`), so `evaluate_all_overlapping_regions(min_thresh=0.8, assigned_col="run1")` reads exactly as it always did; an unknown name raises and lists the valid ones rather than being silently ignored.

Three things stayed out of it:

- **`batch`** replaces the `disable_tqdm`/`save` pair. Those were set together for every run driven by a runner and never otherwise — quiet, and the FOV's own element written, which for a pooled worker is how its result gets back at all. Either half is still sayable alone: `ParamSweeper` is `batch=True, save=False`, a batch that defers its writes.
- **`defer_region_tables`** is deliberately *not* part of `batch`, because it does not track it: the pooled runner defers (the tables span every FOV, so the parent merges them once), while a sweep is a batch that still keeps its own rows.
- **How a candidate is scored** belongs to the scoring method, not here: what a method is scored alongside is its class's `region_context` declaration, and scoring by squared error is a method of its own (`"mse difference"`). Neither is on `RegionEvalParams`. The pre-refactor flags `use_conf_trs`/`use_mse_score` are no longer accepted; passing either raises as an unknown evaluation parameter.

**Choosing the scoring method in the call.** Both evaluate methods take `scoring_method` (a registered name) and `scoring_params` (that method's parameters, in full) next to `params`/`**overrides`. They are not `RegionEvalParams` fields, since how a candidate is scored is still the method's business. They go through `use_scoring(method, params)`, which builds and prepares the method unless the one in force was built by an earlier call asking for exactly the same thing, then leaves it in force:

```python
asgn.evaluate_all_overlapping_regions(
    assigned_col="mse_run", min_thresh=0.8,
    scoring_method="mse difference", scoring_params={"cats": "celltypes", "normed": True},
)
```

The reuse is what keeps a per-FOV loop (or a sweep) from re-preparing on every call; for the classifier that means retraining. `set_scoring_method` clears the remembered request, so a method changed by hand is rebuilt when next asked for by argument. In a pooled run the method is prepared once in the parent, before any worker starts, and each worker is handed it prepared.

**Additive matrix by default.** With no scoring arguments, the method in force is used, prepared if it is not yet. If nothing has been chosen at all, it is `"additive matrix"` with its default parameters, built and prepared on the spot. `cats` is then inferred from the table `generate_cxg_table` left (`default_cxg_table`). `require_scorer`, and so `score_tr_assignment`, falls back the same way. In `evaluate_overlapping_regions_single_fov` this happens after the "already present" skip, so a call with nothing to do prepares nothing, and before the scan, which needs the method's cell types.

### Scoring methods (scoring.py)

How a candidate assignment is judged is a **scoring method**, an object rather than a pair of flags. Each one has two halves:

- **`prepare()`** — the reference, built once. For the methods here that is the per-cell-type average expression matrix; for another it might be a classifier, a marker set, a neighbourhood graph. Any preparation a method needs belongs here, not in the resolve loop.
- **`score(assignment, context)`** — one candidate, called tens of thousands of times per FOV. The hot path.

What a method is scored *alongside* is a **region context**, and those are the assigner's, not the method's: `SoftAssigner.REGION_CONTEXTS` maps a name to a builder taking `(cells, conf_trs, assigned_trs)` and returning `{cell: [transcript id, ...]}`. A method names the one it wants; a new context is added once, there, and every method can then name it.

`SoftAssigner.set_scoring_method(name, **params)` chooses one and `prepare_scoring()` builds its reference; `get_scoring_matrix(...)` still does both for a cell-type method — `"additive matrix"` unless `method=` names another — which is what every existing script calls. `scoring_methods()` lists what is registered.

**Two declarations on the method, not arguments** — set once by the subclass, because each follows from what the method does and neither varies between runs of it. A subclass states one only when the default does not suit:

- `region_context` — *which* region context `score` is handed, **by name**. The contexts themselves are not on the methods: they live on the assigner, in `SoftAssigner.REGION_CONTEXTS`, so adding one there makes it available to every method. `"new_trs"` (the default) hands `score` the transcripts the candidate is placing and nothing else; `"conf_trs"` adds everything already settled in the cell — its confident transcripts plus whatever earlier regions of the FOV have given it. `build_region_context` builds the named one once per ambiguous region and hands the result to every `score` of that region, since a region's candidates differ only in where its ambiguous transcripts go.
- `use_qc_filter` — whether the table this method is prepared from should be QC-filtered first. `CellTypeScoring` declares `True`: its reference is an average profile per cell type, so a cell carrying mostly noise drags its type's row toward noise.

Neither is on `RegionEvalParams`, `resolve_overlapping_regions` or `get_scoring_matrix`.

**The QC filtering itself lives on the assigner**, in `scoring_table(adata, table_name, **bounds)`: it resolves which table to score (the one `generate_cxg_table` left, unless one is handed in or named) and applies `filter_for_scoring` with the bounds from `attrs["qc_cells"]` or the call. The bounds belong to the dataset — what counts as too few transcripts depends on the panel — so they are the assigner's; only the decision to apply them is the method's. `prepare_scoring` calls it and hands the method the result, so what to score is the assigner's business and how to score it is the method's. The bounds that were applied still reach `attrs["scoring"][col]["scoring"]["qc_cells"]`, since they shaped the reference.

**Scoring by cell type — `CellTypeScoring`.** The base class of both registered methods; it is not registered itself, since it has a reference but no way of scoring against it. It owns everything the two share: the parameters (`cats`, `table_name`, `normed`), `prepare` (the per-cell-type average expression matrix, plus `cell_to_type` as a side effect), `use_qc_filter = True`, and a `score` that walks the cells of a candidate — the ones it places transcripts in, plus any the context says hold settled transcripts — and sums `score_cell(row, columns)` over them. **Untyped cells score as "other".** The reference has a row per type plus the `OTHER` row (`"other"`), the average over every cell of the table, typed or not. There is no row for untyped cells. `_type_row` sends the notional "other" cell of a one-cell comparison, any cell with no type, and a cell whose type the QC emptied out to `other_row`. Missing spellings (`MISSING_TYPES`) are dropped from `cats` even when named explicitly, and `infer_cats` never offers them, so `"None"` is never a type of its own. `"Unassigned"` is one of those spellings: the scan always treated it as untyped, and now the mapping and the scoring do too.

**Two kinds of untyped cell, treated differently under `use_other_cells=True`.** `scoring_table` keeps the cells its QC filter dropped as `assigner.qc_excluded_cells`. A region holding one of those is skipped exactly as it would be under `use_other_cells=False`, since what is in such a cell is not trusted enough to compare. A cell that passed QC but has no label *is* compared, scored against `"other"`. In the check for whether a region spans at least two types, all untyped cells count as one group, which is what lets a region of one typed and one unlabelled cell be evaluated at all. Under `use_other_cells=False` none of this applies: every region holding any untyped cell is skipped before scoring, so those results do not depend on how untyped cells would score. On the real store the recorded QC drops 433,926 of 595,230 cells, so most untyped cells there are QC-excluded rather than unlabelled.

A child only says what one cell is worth: `row` is the cell type's matrix row, `columns` the matrix column of each transcript's gene, with genes outside the matrix already dropped. `as_method(name)` hands a prepared reference to a sibling without preparing again (the state it copies is `REFERENCE_STATE`). Only methods whose reference is the matrix alone (`matrix_reference`) can share one.

- **`"additive matrix"`** (`AdditiveMatrixScoring`) — the method the package started with: sum, over every transcript placed, of that gene's average in the receiving cell's type. Default `region_context`, `"new_trs"`: every candidate of a region places the same transcripts somewhere, so settled ones would add the same amount to each and change nothing.
- **`"mse difference"`** (`MseDifferenceScoring`) — the negative squared error between a cell's gene tally and its type's row. It declares `region_context = "conf_trs"`, because it compares a whole profile: a handful of placed transcripts against an average cell's worth of expression would be almost all error, whichever cell they went to. Each cell is negated separately and summed, which is exactly the negation of the summed error.

- **`"ml classifier"`** (`MLClassifierScoring`) — trains a small PyTorch network in `prepare` (genes → `hidden` ReLU → types, Adam, cross-entropy) on the QC-filtered table, labelled from `cell_to_type` after the shared preparation has built it, so it learns exactly the types the evaluation asks about. Each cell contributes the log-probability the network gives its own type, so a candidate's score is the log of the joint probability that every cell is classified correctly. It declares `"conf_trs"`: the network learns from whole cells, so it is scored on whole cells. A cell with no correct label (untyped, or the notional "other") contributes its likeliest type's log-probability.
  - **Training:** input is `log1p(counts / total * scale)`, with `scale` the median training total. `augment` thins each training cell binomially to a random 30–100%, since a cell being scored is often partial. `balance` weights the loss by inverse class frequency. `val_fraction` is held out and reported, with the loss curve, in `scorer.history`, and logged.
  - **Scoring:** after training, the weights are copied to numpy (`weights`) and `score_cell` runs the forward pass there, because torch's per-call overhead would dominate a network this size at tens of thousands of calls per FOV. Results are cached per (type row, transcript multiset).
  - **Measured on the real store:** training takes 20 s on GPU (130k cells, 15 types, 0.93 held-out accuracy). FOV 0001 evaluates in 6.0 s, the same as additive.
  - **Torch** is an optional extra (`softseg[classifier]`), imported only in `prepare`. Workers never need it, since they score in numpy.
  - It declares `matrix_reference = False`, so `as_method` refuses to share its reference with the matrix methods, or theirs with it: it has a model the others lack.

Both matrix methods are bit-identical, per candidate, to the single flagged method they replaced (the old `use_mse_score=False`/`True` under the same context).

**How each column was produced is recorded in the sdata.** `attrs["scoring"][assigned_col]` holds one entry per assignment column, written by `record_scoring` when the column is written and read back with `scoring_params(col)`. It has three parts:

- **`evaluate`** — the `RegionEvalParams` the evaluation ran with (`asdict`), plus `fovs`, every FOV evaluated into the column so far. FOVs accumulate across calls, since a column is often built up over several, while the other values are those of the latest call.
- **`scoring`** — the method's `method` name and parameters, the `region_context` it was scored under, and `qc_cells` for a method that QC-filters. `table_name` and `source` are left out (`UNRECORDED_SCORING_PARAMS`): they say where the reference was read from, not how it scores.
- **`blur`** — `blur_params()` at the time, i.e. the `attrs["blur"]` vouching for the `cell_ids` the evaluation read, or None when nothing did.

Everything passes through `_json_safe` (numpy scalars to python, tuples and sets to lists), so it survives zarr's JSON. In a pooled run the parent writes the entry once after the pool, with `sel_fovs` as its FOVs, for the same reason the region tables are written there: attrs is a single shared file and several workers would race on it. Entries written before this change are flat (`{"method": ..., ...params}`) and are not rewritten; a column re-evaluated gets the new layout.

**Adding one** means subclassing `ScoringMethod`, declaring a `name` (plus a `region_context` or `use_qc_filter` where the defaults do not suit), taking whatever parameters it needs, and registering it. The module docstring carries a complete worked example — a marker-count method with a parameter set of its own, which plugs in with no changes anywhere else. `params` has to return values that survive zarr's JSON, since that is what lands in attrs.

Two things the refactor corrected, both in the MSE path and both verified against the old implementation:

- The negation was **inside** the per-cell loop and flipped the running total, so a multi-cell region scored `cell1 - cell2` rather than `-(cell1 + cell2)`. Each cell's error is now negated on its own before summing, which comes to the same `-(cell1 + cell2)`. Single-cell regions were unaffected, which is why it survived.
- Under `use_conf_trs` the winning candidate used to have the merged-in settled transcripts subtracted back out, and **dropped a cell's new transcripts entirely when that cell held none to subtract**. A candidate now only ever contains the ambiguous transcripts, so there is nothing to subtract.

4. **`generate_cxg_table(...)`** — Builds the cell-by-gene table from all completed per-FOV assignment results, labelling each cell with its `fov`, `size` and centroid. `size` is the cell's exact voxel count from the labels array — the same measure `min_size`/`max_size` filter on. Centroids come from `spatialdata.get_centroids`, which computes the exact voxel-weighted centre across z and maps it through the element's transform. Cells touching a FOV edge are skipped for that FOV, so a cell spanning a boundary is measured by the FOV that holds all of it. The result is stored as a table named `table_name`, defaulting to `cxg` or `cxg_resegmented_{assigned_col}`. Genes and cells are sorted, so the var/obs order does not depend on the order transcripts happen to appear in.

**Coordinate spaces:**
- Cell polygons and transcript `x`/`y` share the FOV's pixel space. A contour traced from the labels array is in mask-array indices, while a transcript at `(x, y)` sits at mask pixel `[y - 1, x - 1]`; `masks_to_shapes` shifts every vertex by `polygon_offset` (1.0) to close that gap, so transcripts test against polygons directly.
- `obs["x_coords"]`/`["y_coords"]`/`["z_coords"]` are in the sdata's `"global"` system, which carries the FOV's offset within the experiment and the physical pixel size, if one was encoded. They follow spatialdata's raster convention, where voxel `i` is centred at `i + 0.5`. `obs["size"]` is a voxel count.
- `spatialdata.to_polygons` is deliberately **not** used for the cell polygons: it rejects 3D labels outright, and its pixel-edge geometry does not line up with the transcripts' 1-based coordinates the way the contour polygons do.

**Important conventions:**
- Cell IDs in mask images are 1-indexed (mask value `m` corresponds to cell ID `m-1`)
- For 3D images, `global_z` in transcript CSV must align with z-slice indices in the mask. Which slice a transcript belongs to is resolved by the `valid_z`/`snap_z` policy recorded in `sdata.attrs`, the same rule `aggregate_zslice_shapes` and `select_zslice` use.
- `dist_between_slices` enables neighbor-slice projection when a cell has no contour on a given z-slice. Left as `None` it is read from the sdata's coordinate system: the z scale of the labels' `"global"` transform, divided by the in-plane pixel size so the result is in pixels and can be combined with in-plane distances. Pass a number to override, or `project_neighbor_slices=False` to disable.
- Pool workers pass results back by saving their own FOV's element to the store, so `pool_size > 1` **requires** a backed sdata and raises otherwise — separately for an object that was never saved and for one detached from a store it knows. The store is re-read after a pooled run, since the elements workers rewrote are newer than the ones the parent holds. Before the pool starts, `SpatialDataHelpers.ensure_element_groups` creates any missing top-level group (`shapes/`, `tables/`, …). spatialdata creates a group on the first write of that kind by checking and then creating it, so two workers writing their first shapes element at once collided with `ContainsGroupError`. That happened on any store with no shapes yet.
- Pool workers do **not** fork — fork deadlocks once the parent has touched the zarr store through dask, which happens as soon as a dataset is converted or read in the same session. Workers therefore re-import `__main__`, so scripts using `pool_size > 1` need an `if __name__ == "__main__":` guard, and `decay_func` must be picklable. `pool_size=1` skips multiprocessing entirely.

### CellTypeAssigner

Wraps a scanpy `AnnData` object for iterative hierarchical cell type annotation. The target cell-by-gene data comes from the sdata (`sdata` + `table_name`, where `generate_cxg_table` leaves it) or as an `adata` directly; `save_annotated_adata` stores the annotated version back as a table. There is no h5ad path in or out — the only reference to one left in the package is the URL `download_lung_dataset` fetches the public cellxgene reference from.


- `ref_levels` / `ann_levels`: column names in reference/target obs for each level of the cell type hierarchy
- Workflow: `get_celltypes()` → `get_clusters()` → `plot_raw_clusters()` → `assign_cluster_celltypes()` → `merge_target_adata()`
- Uses Wilcoxon rank-sum test via `sc.tl.rank_genes_groups` for marker gene identification

## Dependencies

`anndata`, `scanpy`, `numpy`, `pandas`, `opencv-python`, `scikit-image`, `matplotlib`, `seaborn`, `tqdm`, `parse`, `pathspec`; optional extras `classifier` (torch), `neighbors`, `plotting`

### ParamSweeper (SupportFuncs)

Sweeps parameters over one SpatialData. Every point works on the same object, so the bookkeeping is done with columns rather than separate output directories: each assignment goes to a column of its own, named after its scoring method and numbered (`additive_matrix_1`, `mse_difference_1`, …). What produced a column is not in its name but in `attrs["scoring"][column]` (evaluation arguments, scoring method and parameters, blur), so the name only has to be unique.

**`sweep(blur=, scoring=, evaluate=, ...)`** crosses any set of parameters of any of the three kinds. Each argument is `{parameter: [values]}` — or a bare value for one held fixed — and the sweep is their product. Which parameters exist is not the sweeper's business: `scoring` takes whatever the named scoring method takes (its `"method"` key picks one, so a sweep can cross methods with entirely different parameter sets), and `evaluate` takes whatever `RegionEvalParams` holds.

```python
sweeper.sweep(
    blur={"min_size": [25, 50], "max_dist": [3.5, 10]},
    scoring={"method": ["additive matrix"], "normed": [False, True]},
    evaluate={"min_thresh": [0.7, 0.8], "default_thresh": [5, 10]},
)
```

**The loops are ordered by what each parameter invalidates**, so no point pays for work an earlier one already did: blur outermost (it rewrites `cell_ids`, so everything follows it), then scoring (its reference has to be rebuilt), then the evaluation parameters a *scan* depends on (`RegionEvalParams.SCAN_KEYS`), and innermost the ones that only change how a scan is resolved. Sorting transcripts into confident and ambiguous is the expensive half of an assignment, so one scan is reused across every value that does not depend on it. A 2×2×2×3 sweep blurs twice, prepares scoring four times, scans eight times and assigns 24 times.

**Scoring goes through the evaluate methods' own arguments.** For each scoring point, `scoring_request` turns the point into `(scoring_method, scoring_params)`; a point with no `"method"` takes the default. The sweep calls `asgn.use_scoring` with that request before scanning, because the scan already needs the point's cell types. It then hands the same pair to every `evaluate_overlapping_regions_single_fov` call through `assign`, and those calls find the method prepared and reuse it, so a scoring point is prepared exactly once. The table scoring reads travels as the method's `table_name` parameter, added only for a method that takes one:

- `run_unit_sweep` passes its table's name, after `unit_test_table` has fixed that table in place.
- A sweep handed an `adata` that is one of the sdata's tables uses that table's key.
- Any other `adata` is put into the sdata in memory as `REFERENCE_TABLE` (`"sweep_reference"`) and never saved.

`ParamSweeper.prepare_scoring` goes through the same path and never writes to the store.

Two hooks keep the sweep itself free of anything dataset-specific: `rate(sweeper, column, point, frames)` returns metrics merged into that point's result row, and `after_blur(sweeper, blur_point)` runs between re-blurring and scoring — where a real sweep regenerates the cell-by-gene table the scoring reads, since blurring changed what is in each cell.

`column_name(method)` hands out the next free name for a method: its name with spaces as underscores, then one past the highest number already used for it in the swept FOVs' transcript tables or the attrs record. It also remembers the names it issued this session, before anything is written. A second sweep therefore adds columns rather than overwriting the first's, and a fresh `ParamSweeper` over the same store carries on the numbering. `assign(name=None)` takes the next name for the method in force. The old parameter-derived names (`assigned_size25_dist3.5_default10_min0.8`, `NAME_ORDER`/`NAME_ABBREV`, `param_name`) are gone; a result row still carries every parameter of its point next to its `column`.

`run_unit_sweep` is now a thin wrapper over `sweep` for the simulated datasets, scoring each point against the ground truth with `rate_unit_test`. Its original call shape and column names are unchanged, and `scoring=`/`evaluate=` can layer any other axis on top of its four. `scoring` there takes any registered method, or several. Its two defaults, the simulation's `cats` and `normed=False`, are given only to a method that takes them (`method_takes`, read off the method's `__init__` signature), so `scoring={"method": ["additive matrix", "mse difference", "ml classifier"]}` works even though the classifier has no `normed`.

**Methods with different parameters** go in as a *list* of scoring dicts, and `sweep` covers the union of each one's product (`_scoring_points`). Crossing them in one dict would hand every method the others' parameters:

```python
scoring=[
    {"method": ["additive matrix", "mse difference"], "normed": [False, True]},
    {"method": "ml classifier", "epochs": [10, 30]},
]
```

### DatasetFormatter (SupportFuncs)

Builds a `SpatialData` out of the SoftSeg loose-file layout — per-FOV transcript CSV, integer-labelled mask TIFF, optional raw image TIFF, addressed by `.format(fov)` path patterns, placed by a `fov_locs` mapping. This is for example and legacy datasets; data from a supported platform should use the standard `spatialdata_io` readers.

`softseg_to_spatialdata(...)` splits every element by FOV (`{fov}_image`, `{fov}_labels`, `{fov}_points`), gives each FOV its own coordinate system plus the shared `"global"` one, and records the z-correction policy (`z_offset`, `snap_z`, `valid_z`) in `attrs[SpatialDataHelpers.SOFTSEG_ATTRS]`. Pass `save_loc=` to write the store as it goes, which is what `SoftAssigner` then needs for parallel runs.

**Naming a FOV's coordinate system is this converter's business alone.** `DatasetFormatter._fov_coordinate_system` produces the `f"fov_{fov}"` name when stamping it onto new elements. Nothing that *reads* an object rebuilds that string: `SpatialDataHelpers._element_fov_cs(element)` recovers the name from the element's own transformations, by discarding `"global"`, the `"global_only_*"` systems and `STACK_3D_CS`. So an object built by a different reader — whose FOV systems are named anything at all — works unchanged.

### UnitTestWarper (SupportFuncs)

Turns the st-qc simulation object (shapes `cells`/`cell_borders`, points `transcripts`, table `counts`) into the layout `SoftAssigner` reads, so a simulated dataset can be fed straight through the pipeline. `UnitTestWarper(sdata, fov="0000").run(...)` warps the cell boundaries to stand in for imperfect segmentation, then emits:

- `labels[f"{fov}_labels"]` — the warped cells rasterized, using the SoftSeg convention that mask value `m` is cell id `m - 1`.
- `points[f"{fov}_points"]` — the transcripts in that mask's pixel space, 1-based, with the untouched simulation coordinates kept as `global_x`/`global_y`.

Both carry `fov_{fov}` + `"global"`, and the z policy goes into `attrs`. The ground truth (`cells_warped`, `cell_borders_warped`, `counts_warped`) stays alongside. Note the warped shapes are deliberately **not** named `{fov}_z{z}_shapes`: they are in global coordinates, so `get_cell_shapes` reusing them would measure distances in the wrong space — it contours the mask instead.

There is no `out_loc`: every element is saved into the object's own store as it is produced. A run consumes `transcripts`, so re-running (sweeping warp amplitude, say) rebuilds them from `global_x`/`global_y`, dropping any assignment columns a previous pass left behind since those were made against the old segmentation.

### Outputs live in the store

Nothing in the pipeline writes a side-car file next to the zarr. Results are elements: transcript columns on the points, cell-by-gene and delta tables in `tables`, label images in `labels`. `UnitTestWarper.run` follows the same rule — it emits the label image and transcripts as elements rather than as a `.tif` and `.csv` alongside a zarr.

That coordinate system is how transcript locations reach the label image's pixel grid: `rasterize` snaps its grid to whole pixels, so the grid origin is not exactly the `min_coordinate` it was asked for, and the old `(x - min_x) * scale**2` shift was off by a fraction of a pixel. Composing the transcripts' transform with the inverse of the raster's own `"global"` transform is exact, and it is carried by the object rather than by a separate file.

### SegImagePlotter (SupportFuncs)

Draws a FOV's segmentation over its raw image, one z-slice at a time, reading from the same layout `SoftAssigner` uses: `labels[f"{fov}_labels"]` and, when present, `images[f"{fov}_image"]`.

`SegImagePlotter(sdata, fov=None)` then `plot_subset(target_cell, highlight_cells, adata, highlight_type, single_channel, transcripts)`. A cell in `highlight_cells` is outlined red, one whose `adata.obs` row matches `highlight_type` white, everything else black; `target_cell` zooms to that cell's extent plus a 100px border, plots only the slices it appears on, and is outlined red itself — it is the cell being looked at, and it is already what a transcript's colour is measured against, so it is in focus for both.

`transcripts` draws individual transcripts over the segmentation, read from `points[f"{fov}_points"]`. Pass the name of an assignment column and what it means depends on whether anything is in focus: with a `target_cell` or `highlight_cells` it is **those cells' claim on the data** — every transcript either that column or `og_cell` places in them, plus every one they were a candidate for and lost, via `cell_transcripts` — and with nothing in focus it is the whole FOV's edits, via `changed_transcripts(assigned_col)`, which finds every transcript whose column differs from the `og_cell` the run started from, comparing as plain objects so a transcript only one of them placed is not lost to NA propagation. The scoping is the difference between a readable plot and one that looks broken: for one real cell, 162 transcripts belong to it and 1 of them was moved, so a zoomed plot of the unscoped reading draws 10 markers, 9 of them other cells'. A frame from either method is drawn as given — that is how to see a zoomed-to cell's *edits* rather than its claim — and a plain list of transcript ids works too. Each marker is coloured by where it stands relative to the cells in focus (`target_cell` plus `highlight_cells`): cyan for one that stayed in, green for one moved in, magenta for one moved out, grey for one a focus cell was in the running for and did not get, yellow for one that moved between cells that are not in focus, which is also what everything gets when nothing is in focus. `TRANSCRIPT_LABELS` names each of those in a legend below the axes — keyed on what the *slice* drew, so it only ever names colours that are on the plot in front of you: a slice holding nothing but the cell's own transcripts is not keyed for moves that happened two slices up, and a slice with no transcripts on it gets no legend at all. It follows that the legend changes between slices of one call. Below the axes because the crops are tight around a cell and a legend inside one would cover it. Only the transcripts on the slice being drawn and inside the crop appear on it.

`changed_transcripts` is a run's *edits*, which for a single cell is typically one or two transcripts — the step only moves what was ambiguous. `cell_transcripts(cells, assigned_col=None, og_col="og_cell", candidates=True)` is the cell's *claim*: every transcript either column places there, **and every one the cell was in the running for**. A cell is in the running for a transcript when it appears in that transcript's `cell_ids` map — the set `blur_fov` scored it against and the set `evaluate_overlapping_regions` chose from. The ones it did not get are the reason it has the ones it did, so they belong on the same plot; they come back flagged in a `considered` column, which is what `transcript_groups` colours grey. `og_col` is a default rather than something the caller asked for, so a store that never recorded it reads the one assignment it does have; a named `assigned_col` that is absent is an error.

`_considered_by` is the lookup. There are hundreds of thousands of `cell_ids` strings per FOV and parsing all of them would dominate the plot, so a substring test over the raw column narrows it first — an id appears in the text of any map holding it, quoted keys or bare — and only the survivors are parsed, which settles the over-matches the substring test lets through. For one cell of a 391k-transcript FOV that is ~0.5s.

Which slice a transcript is drawn on is the slice it was *assigned* on — `valid_slices`/`_slice_of` apply the same `valid_z`/`snap_z` policy from `sdata.attrs` that `SoftAssigner.transcript_slices` does, and a 2D FOV puts everything on slice 0. Rounding the raw `z` instead silently disagrees with the run being drawn: in a 2D FOV whose transcripts carry any non-zero z, every marker lands on a slice that does not exist and nothing is drawn at all.

The rest — a transcript on no segmented slice, on a slice the zoom does not cover, or outside the crop — is counted up in a warning once the last slice is drawn, because a plot that dropped them looks exactly like one with nothing to draw. Zooming to a typical cell is that case: the changed transcripts of a whole FOV number in the thousands but only a handful sit on the cell being looked at.

Transcript markers are drawn with a plain `ax.scatter` on the axes `pl.show` hands back (`_draw_transcripts`), not through `render_points`. That path builds an AnnData per call to reach scanpy's colouring, and doing so warns twice over — a deprecated `dtype=`, and an integer index anndata rewrites as strings — before matplotlib warns again that the `cmap`/`norm` it always passes have nothing to colour-map. Three warnings per call, six calls a plot, and none of them mean anything here: the colours are already decided, one per group, and a scatter takes them directly. The markers are already in the crop's display space, which is the space `pl.show` leaves the axes in, so they need no transform.

A transcript at `(x, y)` sits at mask array position `[y - 1, x - 1]` and array cell `i` spans `[i, i + 1]`, so the marker lands half a pixel in, shifted by where the crop window starts — the same half-pixel `_cell_polygons` applies, which is what puts a cell's transcripts inside its outline.

Rendering goes through `spatialdata_plot`: each slice becomes a small 2D `SpatialData` holding the cropped image and the slice's cells, and `render_images(channel=single_channel)` puts the image underneath. `spatialdata-plot` is imported lazily and lives in the `plotting` extra, so the rest of the package does not depend on it.

The cells are drawn as **shapes, one polygon per cell** (`_cell_polygons`), not as labels. `render_labels` colours by category, so every cell sharing a colour is one region to it and two neighbours that touch come out as a single ring around the pair with no border between them — the merged boundary. A polygon per cell is a polygon per cell however they are coloured, so each keeps its own closed outline. They are contoured with the same `SpatialDataHelpers._slice_to_polygons` the pipeline uses, so the ring drawn is the boundary transcripts were measured against — it runs through the centres of the boundary pixels, which is why a polygon covers ~90% of its cell's pixels rather than all of them. Each cell is contoured inside its own `find_objects` bounding box, which is what makes this affordable on a full FOV (~900 cells in ~1s). One shapes element per outline group, rendered in `OUTLINE_COLORS` order so a highlighted cell's ring is never overdrawn by a neighbour's.

`pl.show` is called with `return_ax=True, show=False` so the legend can go on and the axes can be pinned to the crop before the figure is drawn — pinning them matters because with no image the shapes alone would set the extent, and every slice would be framed differently. It also means one figure per slice instead of the two `pl.show`'s own `plt.show()` used to produce.

`CONTOUR_PX = 1` is the outline width, a `render_shapes` line width — thin, so two neighbours' rings stay legible as two rather than running together into a band. `TRANSCRIPT_PX = 20` is the marker size and `TRANSCRIPT_EDGE_PX = 0.8` the dark edge around it: the microscopy underneath is red/green/blue everywhere, so a marker needs contrast it carries itself rather than a colour that happens to differ from whatever it lands on. Both are sized for a cell's worth of transcripts — a few dozen on a slice — not for the handful a run moved.

### AssignmentComparer (SupportFuncs)

Compares two assignments of the same transcripts. `AssignmentComparer(sdata, "left_col", "right_col")` reads both columns from one object; `right_sdata=` reads the second from another, which is how a pre-refactor run is compared against a current one. `sel_fovs=` narrows the comparison, defaulting to every FOV both sides carry their column for. It never writes — given a path or object it builds a `SoftAssigner(save_to_disk=False)`, and an assigner you already have is used as-is.

`summary()` returns every metric as a dict, `per_fov()` the same per FOV, `report()` a few printable lines. The metrics fall in three groups:

- **agreement** — how many transcripts each side placed, how often in the same cell, and `adjusted_rand_index`, which asks whether the two agree on *which transcripts belong together* regardless of what the cells are called (so it is meaningful between runs that numbered cells differently). The module-level `adjusted_rand_index` computes it from a contingency table rather than through scikit-learn, which is an optional dependency here.
- **movement** — of the transcripts each side moved off the original segmentation (`og_col`, default `og_cell`), how much those two sets overlap and how often the two agree on where a moved transcript went. Skipped when the column is absent.
- **composition** — `cell_by_gene(side)` tallies a cell-by-gene matrix straight from the transcripts, so it needs no segmentation and works against a faked sdata. `cxg_jaccard()` compares the two over the union of their cells and genes, both as `binary` (which (cell, gene) pairs have any count) and `weighted` (sum(min)/sum(max), so how much of the total signal is placed identically). `per_cell()` breaks that down per cell alongside the Jaccard of each cell's transcript set.

`disagreements()` hands back the rows behind `n_disagree`.

**Streaming.** Every metric folds the FOVs in one at a time through `_CompareTally` rather than working over one big table: `iter_frames()` builds a FOV's frame, hands it over and drops it before reading the next. `summary()`, `per_fov()`, `cxg_jaccard()`, `per_cell()`, `cell_by_gene()`, `disagreements()` and `candidate_agreement()` all work this way, so what they cost follows the largest single FOV and the size of the answer rather than the number of FOVs. Measured over the same FOVs both ways: 2 FOVs +1.40GB streamed against +1.61 gathered, 4 FOVs +1.39 against +1.86, 8 FOVs +4.87 against +6.35 — the streamed figure tracks the biggest FOV in the set, the gathered one tracks the sum.

The arithmetic is exact, not approximate. Every metric is either a count, which adds, or comes from a table whose size follows the *result* rather than the data: the contingency of (left cell, right cell) pairings behind the Rand index (`adjusted_rand_index_from_pairs`), the set of cells each side used, and the two cell-by-gene tallies. The median per-cell Jaccard is the one thing that does not add, and it does not need to — it is computed at the end from the accumulated per-cell counts. A streamed run and a gathered one over the same FOVs give bit-identical numbers, which is worth re-checking after any change here.

`stream` is automatic: on when either side holds one FOV at a time, off otherwise, and overridable. `transcripts()` is the one method that still holds everything, kept for looking at rows over a few FOVs; in streaming mode it does not cache, since keeping it is what streaming is avoiding.

Comparisons run on plain object arrays rather than on the nullable columns themselves: `!=` between them propagates NA, which would drop a transcript one side placed and the other did not out of the comparison instead of counting it as a difference.

### LegacyRunLoader (SupportFuncs)

Fakes a `SpatialData` out of a pre-refactor run's `complete_loc` directory, so an old result can go through `AssignmentComparer` or any `SoftAssigner` step that only needs transcripts. `LegacyRunLoader(complete_loc).to_sdata(sel_fovs=None)` reads:

- `fov_{fov}_cellids.csv` → `points[f"{fov}_points"]`, keeping every column the old run wrote (`cell_ids`, the assignment columns, `og_cell`/`og_type`). The transcript id arrives as the frame's unnamed index and is restored as the `index` column; `z` is taken from `global_z`, which is what the old code indexed mask slices with.
- `overlap_eval_{col}_fov_{fov}.pydict` → the `assigned_trs_{col}` table, in the shape `evaluate_overlapping_regions_single_fov` writes now.
- `*.h5ad` → tables named by file stem, but only when asked: `load_tables` is False by default, since each file is a whole cell-by-gene matrix (26 files, 19GB, in one real output directory) and a comparison needs none of them. True reads all; a name or list of names reads those, matched against the stem or as a glob. `h5ad_files()` lists what is there.

The `assigned_trs_{col}` tables are named *after* the column they record, not instead of it. To compare an assignment, pass `AssignmentComparer` the column (`"thresh5_min0.7"`) rather than the table (`"assigned_trs_thresh5_min0.7"`); `assignment_columns(fov)` lists the columns from the CSV header alone. Naming a table where a column belongs is the mistake the comparer's error message calls out by name.

The result is in memory and never written; there are no labels or images in it, so steps that read a segmentation are not available. `delta_tallies_*.pydict` files hold the assignments rather than the tallies — the code that wrote them passed the wrong variable — so they are read back as what they contain, under a `{col}_delta_tallies` name.

**One FOV at a time.** `to_sdata()` over a whole run reads every CSV and keeps them all — 294 files and 57GB in one real directory, which does not fit anywhere. `loader.streaming()` returns a `LegacyFovView` instead: it offers `AssignmentComparer` the surface an assigner has, but builds the assigner for a FOV when asked and drops the one before, so the directory is visited rather than gathered. `fov_sdata(fov)` is the single FOV on its own if you want it directly. Handing `AssignmentComparer` the *loader* does this for you — it takes the streaming view, since reading a run a FOV at a time is the only way that scales.

What the comparison asks *about* the data — which FOVs exist, which carry a column — is answered from the CSV headers alone (`columns`, `has_column`, both cached), so choosing what to compare reads no rows. That matters: resolving FOVs used to mean loading each one to look at it.
