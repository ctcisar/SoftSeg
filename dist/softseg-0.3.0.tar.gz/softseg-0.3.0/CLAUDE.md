# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Package Overview

SoftSeg is a Python package for **soft transcript-to-cell assignment** in spatial transcriptomics. Rather than making hard binary assignments, it assigns each transcript probabilistic confidence scores to one or more nearby cells, based on distance from cell segmentation mask contours. It also includes tools for downstream cell type annotation using a single-cell reference dataset.

## Install & Build

```bash
# Editable install for development
pip install -e .

# Build distributable
python -m build
```

Built with `hatchling`. Package source lives in `src/SoftSeg/`.

## Key Files

- **`SoftAssigner.py`** — Core pipeline class. Handles the full soft-assignment workflow per field-of-view (FOV).
- **`CellTypeAssigner.py`** — Cell type annotation using a single-cell RNA-seq reference via scanpy. Takes its target either as an `adata` or as `sdata` + `table_name`, and `save_annotated_adata` writes the annotated result back as a table in the store.
- **`SpatialDataHelpers.py`** — The SpatialData layer. Everything lives on the `SpatialDataHelpers` class (nothing at module scope), in four labelled sections: (1) coordinate-system conventions (`STACK_3D_CS`, `SOFTSEG_ATTRS`, `_element_fov_cs`), (2) the z-slice machinery `SoftAssigner` uses (slice resolution, the `snap_z`/`valid_z` policy), (3) masks → per-z-slice shapes (`masks_to_shapes`), (4) standalone 3D utilities (`select_zslice`, `aggregate_zslice_shapes`).
- **`SupportFuncs.py`** — Utilities: KL divergence between anndata objects, `SegImagePlotter`, `NeighborPredictor`, `ParamSweeper`, and `DatasetFormatter` (below).
- **`codedump.py`** — Scratch/experimental code; not part of the package API.
- **`test.py`** — Scratch plotting script; not a formal test suite.

## Architecture & Data Flow

### SoftAssigner

Initialized with a single argument, `sdata`: a `spatialdata.SpatialData` object or a path to a zarr store holding one. **It is both the input and the output** — no other paths are involved. Build it with the standard readers for your platform (`spatialdata_io.cosmx`, `xenium`, …), or with `SupportFuncs.DatasetFormatter.softseg_to_spatialdata` for a dataset that exists as the older per-FOV CSV/TIFF file set. It holds per FOV:
- `labels[f"{fov}_labels"]` — segmentation mask, 2D `(y, x)` or 3D `(z, y, x)`
- `points[f"{fov}_points"]` — transcript table (`x`, `y`, `global_z`, `gene`, `index`, plus the `z`/`global_x`/`global_y` the converter adds). Results are appended here as new columns.
- `shapes[f"{fov}_z{z}_shapes"]` — *(optional)* per-z-slice cell polygons
- `tables[...]` — cell-by-gene results and delta tallies

**Persistence.** Every element this class alters is saved back to the store it came from, via `save_element`. Rewriting an element in place is a `delete_element_from_disk` followed by `write_element` — zarr refuses to overwrite a path it is currently backing an element from — so the replacement must already be fully in memory (`set_transcripts` builds it through `.compute()`) before the delete. The pair is not atomic: an interruption between them leaves the element in memory only, and re-running the step rewrites it. An sdata with no store on disk (`is_backed()` false) is worked on purely in memory and never saved.

Transcript tables are read and written through `get_transcripts`/`set_transcripts`, which go directly to the points element's parquet. Columns holding python objects — the `{cell_id: score}` maps in `cell_ids` — are stored as their `str()` repr, since parquet has no type for them, and read back with `ast.literal_eval`.

Progress is tracked by what the data carries, not by which files exist: `get_complete_fovs(column="cell_ids")` and `get_incomplete_fovs(...)` test for the column's presence in the points schema.

Accessors wrap the sdata layout: `get_mask`, `get_transcripts`, `set_transcripts`, `get_cell_shapes`, `get_fov_affine`, `get_dist_between_slices`, `valid_slices`, `transcript_slices`, `has_column`, `save_element`, `save_table`.

**Pipeline stages:**

1. **`blur_all_fovs(...)`** — Runs `blur_fov` across all incomplete FOVs using a multiprocessing `Pool` (`pool_size` parameter). For each FOV: reads mask + transcripts from the sdata, takes one polygon per cell per z-slice (reusing existing `{fov}_z{z}_shapes` elements when present, otherwise contouring the labels via `SpatialDataHelpers.masks_to_shapes`), computes signed distance from each transcript to the polygon on its own z-slice, applies a sigmoid decay function (`sigm()`) to convert distance to a confidence score. Adds a `cell_ids` column to the FOV's points element, storing `{cell_id: score}` dicts as strings, and saves it.

1b. *(Optional)* **Cell type labelling** — `get_scoring_matrix` (step 2) requires cell type labels on each cell. If no external cell type annotation is available, the package provides tools to generate one. `calculate_confident_threshold()` analyzes multiply-assigned transcripts to suggest a `min_thresh` value; this threshold can then be passed to `convert_to_adata()` to produce a preliminary AnnData. `CellTypeAssigner` can then be used to cluster that AnnData against a paired single-cell RNA reference and label each cell with a cell type, producing the annotated AnnData needed as input to step 2.

2. **`get_scoring_matrix(...)`** — Builds a scoring matrix from an AnnData object and a dict of cell type categories (`cats`), used to score transcript-to-cell assignments in overlapping regions.

3. **`evaluate_all_overlapping_regions(...)`** — Resolves ambiguous transcript assignments in regions where multiple cells overlap. Runs `evaluate_overlapping_regions_single_fov` in parallel across FOVs (in batches of 100 to limit memory leakage). For each FOV: transcripts are first split into confident (single clear assignment above `min_thresh`) and unconfident (multiple candidate cells). Unconfident transcripts are grouped by their set of candidate cells; groups where all candidates share the same cell type, or where any candidate is untyped (unless `use_other_cells=True`), are skipped. For each remaining group, a range of soft-score thresholds is swept to generate candidate hard assignments, each scored via `score_tr_assignment` using the scoring matrix from step 2. An assignment only replaces the default (original mask) assignment if it exceeds the default score by a factor of `default_thresh` (default 5×). The best assignment is written to a new `assigned_col` column on the FOV's points element, alongside `og_cell`, `og_type` and `{assigned_col}_type`. With `save_delta_tallies=True`, per-cell gained/lost/changed/final counts are stored as a `{fov}_deltas_{assigned_col}` table — one per FOV, so pooled workers each save their own element.

4. **`convert_to_adata(...)`** — Converts all completed per-FOV assignment results into an AnnData object, labelling each cell with its `fov`, `size` and centroid. `size` is the cell's exact voxel count from the labels array — the same measure `min_size`/`max_size` filter on. Centroids come from `spatialdata.get_centroids`, which computes the exact voxel-weighted centre across z and maps it through the element's transform. Cells touching a FOV edge are skipped for that FOV, so a cell spanning a boundary is measured by the FOV that holds all of it. The result is stored as a table named `table_name`, defaulting to `cxg` or `cxg_resegmented_{assigned_col}`. Genes and cells are sorted, so the var/obs order does not depend on the order transcripts happen to appear in.

**Coordinate spaces:**
- Cell polygons and transcript `x`/`y` share the FOV's pixel space. A contour traced from the labels array is in mask-array indices, while a transcript at `(x, y)` sits at mask pixel `[y - 1, x - 1]`; `masks_to_shapes` shifts every vertex by `polygon_offset` (1.0) to close that gap, so transcripts test against polygons directly.
- `obs["x_coords"]`/`["y_coords"]`/`["z_coords"]` are in the sdata's `"global"` system, which carries the FOV's offset within the experiment and the physical pixel size, if one was encoded. They follow spatialdata's raster convention, where voxel `i` is centred at `i + 0.5`. `obs["size"]` is a voxel count.
- `spatialdata.to_polygons` is deliberately **not** used for the cell polygons: it rejects 3D labels outright, and its pixel-edge geometry does not line up with the transcripts' 1-based coordinates the way the contour polygons do.

**Important conventions:**
- Cell IDs in mask images are 1-indexed (mask value `m` corresponds to cell ID `m-1`)
- For 3D images, `global_z` in transcript CSV must align with z-slice indices in the mask. Which slice a transcript belongs to is resolved by the `valid_z`/`snap_z` policy recorded in `sdata.attrs`, the same rule `aggregate_zslice_shapes` and `select_zslice` use.
- `dist_between_slices` enables neighbor-slice projection when a cell has no contour on a given z-slice. Left as `None` it is read from the sdata's coordinate system: the z scale of the labels' `"global"` transform, divided by the in-plane pixel size so the result is in pixels and can be combined with in-plane distances. Pass a number to override, or `project_neighbor_slices=False` to disable.
- Pool workers pass results back by saving their own FOV's element to the store, so `pool_size > 1` **requires** a backed sdata and raises otherwise — separately for an object that was never saved and for one detached from a store it knows. The store is re-read after a pooled run, since the elements workers rewrote are newer than the ones the parent holds.
- Pool workers do **not** fork — fork deadlocks once the parent has touched the zarr store through dask, which happens as soon as a dataset is converted or read in the same session. Workers therefore re-import `__main__`, so scripts using `pool_size > 1` need an `if __name__ == "__main__":` guard, and `decay_func` must be picklable. `pool_size=1` skips multiprocessing entirely.

### CellTypeAssigner

Wraps a scanpy `AnnData` object for iterative hierarchical cell type annotation. The target cell-by-gene data comes from the sdata (`sdata` + `table_name`, where `convert_to_adata` leaves it) or as an `adata` directly; `save_annotated_adata` stores the annotated version back as a table. There is no h5ad path in or out — the only reference to one left in the package is the URL `download_lung_dataset` fetches the public cellxgene reference from.


- `ref_levels` / `ann_levels`: column names in reference/target obs for each level of the cell type hierarchy
- Workflow: `get_celltypes()` → `get_clusters()` → `plot_raw_clusters()` → `assign_cluster_celltypes()` → `merge_target_adata()`
- Uses Wilcoxon rank-sum test via `sc.tl.rank_genes_groups` for marker gene identification

## Dependencies

`anndata`, `scanpy`, `numpy`, `pandas`, `opencv-python`, `scikit-image`, `matplotlib`, `seaborn`, `tqdm`, `parse`, `pathspec`

### DatasetFormatter (SupportFuncs)

Builds a `SpatialData` out of the SoftSeg loose-file layout — per-FOV transcript CSV, integer-labelled mask TIFF, optional raw image TIFF, addressed by `.format(fov)` path patterns, placed by a `fov_locs` mapping. This is for example and legacy datasets; data from a supported platform should use the standard `spatialdata_io` readers.

`softseg_to_spatialdata(...)` splits every element by FOV (`{fov}_image`, `{fov}_labels`, `{fov}_points`), gives each FOV its own coordinate system plus the shared `"global"` one, and records the z-correction policy (`z_offset`, `snap_z`, `valid_z`) in `attrs[SpatialDataHelpers.SOFTSEG_ATTRS]`. Pass `save_loc=` to write the store as it goes, which is what `SoftAssigner` then needs for parallel runs.

**Naming a FOV's coordinate system is this converter's business alone.** `DatasetFormatter._fov_coordinate_system` produces the `f"fov_{fov}"` name when stamping it onto new elements. Nothing that *reads* an object rebuilds that string: `SpatialDataHelpers._element_fov_cs(element)` recovers the name from the element's own transformations, by discarding `"global"`, the `"global_only_*"` systems and `STACK_3D_CS`. So an object built by a different reader — whose FOV systems are named anything at all — works unchanged.

### Outputs live in the store

Nothing in the pipeline writes a side-car file next to the zarr. Results are elements: transcript columns on the points, cell-by-gene and delta tables in `tables`, label images in `labels`. `UnitTestWarper.run` follows the same rule — it used to emit a `.tif` of the remapped label image and a `.csv` of hand-shifted transcripts alongside `warped_sdata.zarr`, and now stores the label image as `cell_borders_warped_labels` and places the transcripts in a `rasterized_pixels` coordinate system instead.

That coordinate system is how transcript locations reach the label image's pixel grid: `rasterize` snaps its grid to whole pixels, so the grid origin is not exactly the `min_coordinate` it was asked for, and the old `(x - min_x) * scale**2` shift was off by a fraction of a pixel. Composing the transcripts' transform with the inverse of the raster's own `"global"` transform is exact, and it is carried by the object rather than by a separate file.
