# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Package Overview

SoftSeg is a Python package for **soft transcript-to-cell assignment** in spatial transcriptomics. Rather than making hard binary assignments, it assigns each transcript probabilistic confidence scores to one or more nearby cells, based on distance from cell segmentation mask contours. It also includes tools for downstream cell type annotation using a single-cell reference dataset.

## Install & Build

```bash
# Editable install for development
pip install -e .

# Build distributable
python -m build
```

Built with `hatchling`. Package source lives in `src/SoftSeg/`.

## Key Files

- **`SoftAssigner.py`** — Core pipeline class. Handles the full soft-assignment workflow per field-of-view (FOV).
- **`CellTypeAssigner.py`** — Cell type annotation using a single-cell RNA-seq reference via scanpy. Takes its target either as an `adata` or as `sdata` + `table_name`, and `save_annotated_adata` writes the annotated result back as a table in the store.
- **`SpatialDataHelpers.py`** — The SpatialData layer. Everything lives on the `SpatialDataHelpers` class (nothing at module scope), in four labelled sections: (1) coordinate-system conventions (`STACK_3D_CS`, `SOFTSEG_ATTRS`, `_element_fov_cs`, `quiet_ome_zarr`), (2) the z-slice machinery `SoftAssigner` uses (slice resolution, the `snap_z`/`valid_z` policy), (3) masks → per-z-slice shapes (`masks_to_shapes`), (4) standalone 3D utilities (`select_zslice`, `aggregate_zslice_shapes`).
- **`__init__.py`** — Exposes `SpatialDataHelpers` and calls `quiet_ome_zarr()` once on import; see below.
- **`SupportFuncs.py`** — Utilities: KL divergence between anndata objects, `SegImagePlotter` (below), `NeighborPredictor`, `ParamSweeper`, `UnitTestWarper`, `DatasetFormatter`, `AssignmentComparer` and `LegacyRunLoader` (all below).
- **`codedump.py`** — Scratch/experimental code; not part of the package API.
- **`examples/compare_legacy_run.py`** — Runnable example of comparing a current run against a pre-refactor one without loading the old run up front.
- **`test.py`** — Scratch plotting script; not a formal test suite.

### Reading a store is quiet

spatialdata writes a labels element without the image it would be a label *of*, so ome-zarr-py logs `no parent found for ...` every time it reads one ([spatialdata#400](https://github.com/scverse/spatialdata/issues/400)). A per-FOV store has hundreds of labels elements — 295 lines for one real dataset — so opening one buries the session in complaints about a layout this package uses on purpose.

`SpatialDataHelpers.quiet_ome_zarr()` drops those records, and `SoftSeg/__init__.py` calls it on import, so they are gone wherever a store is opened — by this package or by `spatialdata.read_zarr` the user calls themselves. The read paths (`SoftAssigner.sdata`, `SegImagePlotter`, `UnitTestWarper`, `softseg_to_spatialdata`) call it too, so the intent stays legible where the reading happens; it is idempotent, so the repeats cost nothing and no filter stacks up.

It is deliberately narrow: **only** that one message, and only on `ome_zarr.reader`, the logger that emits it. Silencing the whole logger — which three separate places used to do, two of them with `setLevel(ERROR)` — would also hide a real problem reading a store.

## Architecture & Data Flow

### SoftAssigner

Initialized with a single argument, `sdata`: a `spatialdata.SpatialData` object or a path to a zarr store holding one. **It is both the input and the output** — no other paths are involved. Build it with the standard readers for your platform (`spatialdata_io.cosmx`, `xenium`, …), or with `SupportFuncs.DatasetFormatter.softseg_to_spatialdata` for a dataset that exists as the older per-FOV CSV/TIFF file set. It holds per FOV:
- `labels[f"{fov}_labels"]` — segmentation mask, 2D `(y, x)` or 3D `(z, y, x)`
- `points[f"{fov}_points"]` — transcript table (`x`, `y`, `global_z`, `gene`, `index`, plus the `z`/`global_x`/`global_y` the converter adds). Results are appended here as new columns.
- `shapes[f"{fov}_z{z}_shapes"]` — *(optional)* per-z-slice cell polygons
- `tables[...]` — cell-by-gene results and delta tallies

**Persistence.** Every element this class alters is saved back to the store it came from, via `save_element`. `SoftAssigner(sdata, save_to_disk=False)` turns that off wholesale — results still accumulate in the sdata in memory but nothing touches the store, for trying something out against real data without altering it. Saving is the default; a pooled run requires it, since a worker returns its results by saving its own element, and is refused otherwise. The per-call `save=False` on `set_transcripts`/`blur_fov`/`evaluate_overlapping_regions_single_fov` is the narrower version of the same thing, for deferring many successive writes into one. Rewriting an element in place is a `delete_element_from_disk` followed by `write_element` — zarr refuses to overwrite a path it is currently backing an element from — so the replacement must already be fully in memory (`set_transcripts` builds it through `.compute()`) before the delete. The pair is not atomic: an interruption between them leaves the element in memory only, and re-running the step rewrites it. An sdata with no store on disk (`is_backed()` false) is worked on purely in memory and never saved.

Transcript tables are read and written through `get_transcripts`/`set_transcripts`, which go directly to the points element's parquet. Columns holding python objects — the `{cell_id: score}` maps in `cell_ids` — are stored as their `str()` repr, since parquet has no type for them, and read back with `ast.literal_eval`.

Progress is tracked by what the data carries, not by which files exist: `get_complete_fovs(column="cell_ids")` and `get_incomplete_fovs(...)` test for the column's presence in the points schema.

Accessors wrap the sdata layout: `get_mask`, `get_transcripts`, `set_transcripts`, `get_cell_shapes`, `get_fov_affine`, `get_dist_between_slices`, `valid_slices`, `transcript_slices`, `has_column`, `save_element`, `save_table`.

**Pipeline stages:**

1. **`blur_all_fovs(...)`** — Runs `blur_fov` across all incomplete FOVs using a multiprocessing `Pool` (`pool_size` parameter). For each FOV: reads mask + transcripts from the sdata, takes one polygon per cell per z-slice (reusing existing `{fov}_z{z}_shapes` elements when present, otherwise contouring the labels via `SpatialDataHelpers.masks_to_shapes`), computes signed distance from each transcript to the polygon on its own z-slice, applies a sigmoid decay function (`sigm()`) to convert distance to a confidence score. Adds a `cell_ids` column to the FOV's points element, storing `{cell_id: score}` dicts as strings, and saves it.

1b. *(Optional)* **Cell type labelling** — `get_scoring_matrix` (step 2) requires cell type labels on each cell. If no external cell type annotation is available, the package provides tools to generate one. `calculate_confident_threshold()` analyzes multiply-assigned transcripts to suggest a `min_thresh` value; this threshold can then be passed to `generate_cxg_table()` to produce a preliminary AnnData. `CellTypeAssigner` can then be used to cluster that AnnData against a paired single-cell RNA reference and label each cell with a cell type, producing the annotated AnnData needed as input to step 2.

2. **`get_scoring_matrix(...)`** — Builds a scoring matrix from an AnnData object and a dict of cell type categories (`cats`), used to score transcript-to-cell assignments in overlapping regions. `cats` takes either form: `{"column": ["type", ...]}` in full, or just `"column"` — the obs column holding the types, whose labels are then read off it (`infer_cats`). Called with no arguments at all, both are taken from the sdata: the table `generate_cxg_table` stored there (`default_cxg_table`, preferring `"cxg"`), and the one categorical obs column that is neither geometry nor an identifier. Ambiguity is refused rather than guessed — several candidate tables or columns raise and name what they found, so pass `table_name=` or `cats="column"` in that case.

QC bounds can be applied to the table before it is scored, which is what the pre-package notebooks did with `CellTypeAssigner.filter_cells`/`filter_genes` before handing the result over: `min_counts`/`max_counts` bound a cell's total transcript count, `min_genes` its number of distinct genes, and `min_cells` drops genes seen in too few of the *remaining* cells (cells first, then genes, matching the old order). `filter_for_scoring` does the work and agrees with `sc.pp.filter_cells`/`filter_genes` exactly; it never touches the stored table. Two consequences worth knowing: a dropped cell is absent from `cell_to_type`, so it is untyped and an overlapping region containing it is skipped unless `use_other_cells=True`; a dropped gene simply stops contributing to any score, exactly as a blank does. A cell type the bounds empty out is left out of the scoring matrix rather than becoming a row of NaN.

The `{cell id: cell type}` mapping it builds is stored in the sdata as the `cell_to_type` table (`SoftAssigner.CELL_TYPE_TABLE`; `save=False` keeps it in memory). `SoftAssigner.cell_to_type` is a property: an assigner that has not run `get_scoring_matrix` reads the mapping back from that table on first access and caches it, so a store that has been scored once can be picked up again without rebuilding. Only the mapping is stored, not `score_mat` — resolving an overlapping region still needs `get_scoring_matrix`.

3. **`evaluate_all_overlapping_regions(...)`** — Resolves ambiguous transcript assignments in regions where multiple cells overlap. Runs `evaluate_overlapping_regions_single_fov` in parallel across FOVs (in batches of 100 to limit memory leakage). For each FOV: transcripts are first split into confident (single clear assignment above `min_thresh`) and unconfident (multiple candidate cells). Unconfident transcripts are grouped by their set of candidate cells; groups where all candidates share the same cell type, or where any candidate is untyped (unless `use_other_cells=True`), are skipped. For each remaining group, a range of soft-score thresholds is swept to generate candidate hard assignments, each scored via `score_tr_assignment` using the scoring matrix from step 2. An assignment only replaces the default (original mask) assignment if it exceeds the default score by a factor of `default_thresh` (default 5×). The best assignment is written to a new `assigned_col` column on the FOV's points element, alongside `og_cell`, `og_type` and `{assigned_col}_type`. All four name a cell or a cell type per transcript, and all four say "not assigned" the same way: `SoftAssigner.MISSING` (`pd.NA`) in a `"string"` column, built through `as_label_column`. That is what parquet hands back for any absent value however it went in, so a column reads back as it was written instead of changing type on the first reload, and an absent value costs a bit in the validity bitmap rather than a stored string. Stores written before this have the sentinel string `"None"` in the three tracking columns; `generate_cxg_table` and `ParamSweeper._normalize_missing` still treat that as absent, since left alone it reaches `int()` and raises. With `save_delta_tallies=True`, per-cell gained/lost/changed/final counts are stored as a `{fov}_deltas_{assigned_col}` table — one per FOV, so pooled workers each save their own element.

How each assignment was reached is kept alongside it, as two tables per run rather than per FOV: `assigned_trs_{assigned_col}` holds one row per (cell, transcript) pair, `seg_is_default_{assigned_col}` one row per ambiguous region and whether the original segmentation won it. Both carry a `fov` column and keep their content in `obs` on a zero-variable AnnData, since neither is a measurement over genes. Because they span every FOV, a worker cannot save its own — several rewriting one element would leave only whichever finished last — so `evaluate_all_overlapping_regions` collects each FOV's rows (`defer_region_tables`) and merges them once, in the parent, after the pool has finished. Merging replaces a FOV's existing rows when `overwrite` is set and leaves them otherwise.

4. **`generate_cxg_table(...)`** — Builds the cell-by-gene table from all completed per-FOV assignment results, labelling each cell with its `fov`, `size` and centroid. `size` is the cell's exact voxel count from the labels array — the same measure `min_size`/`max_size` filter on. Centroids come from `spatialdata.get_centroids`, which computes the exact voxel-weighted centre across z and maps it through the element's transform. Cells touching a FOV edge are skipped for that FOV, so a cell spanning a boundary is measured by the FOV that holds all of it. The result is stored as a table named `table_name`, defaulting to `cxg` or `cxg_resegmented_{assigned_col}`. Genes and cells are sorted, so the var/obs order does not depend on the order transcripts happen to appear in.

**Coordinate spaces:**
- Cell polygons and transcript `x`/`y` share the FOV's pixel space. A contour traced from the labels array is in mask-array indices, while a transcript at `(x, y)` sits at mask pixel `[y - 1, x - 1]`; `masks_to_shapes` shifts every vertex by `polygon_offset` (1.0) to close that gap, so transcripts test against polygons directly.
- `obs["x_coords"]`/`["y_coords"]`/`["z_coords"]` are in the sdata's `"global"` system, which carries the FOV's offset within the experiment and the physical pixel size, if one was encoded. They follow spatialdata's raster convention, where voxel `i` is centred at `i + 0.5`. `obs["size"]` is a voxel count.
- `spatialdata.to_polygons` is deliberately **not** used for the cell polygons: it rejects 3D labels outright, and its pixel-edge geometry does not line up with the transcripts' 1-based coordinates the way the contour polygons do.

**Important conventions:**
- Cell IDs in mask images are 1-indexed (mask value `m` corresponds to cell ID `m-1`)
- For 3D images, `global_z` in transcript CSV must align with z-slice indices in the mask. Which slice a transcript belongs to is resolved by the `valid_z`/`snap_z` policy recorded in `sdata.attrs`, the same rule `aggregate_zslice_shapes` and `select_zslice` use.
- `dist_between_slices` enables neighbor-slice projection when a cell has no contour on a given z-slice. Left as `None` it is read from the sdata's coordinate system: the z scale of the labels' `"global"` transform, divided by the in-plane pixel size so the result is in pixels and can be combined with in-plane distances. Pass a number to override, or `project_neighbor_slices=False` to disable.
- Pool workers pass results back by saving their own FOV's element to the store, so `pool_size > 1` **requires** a backed sdata and raises otherwise — separately for an object that was never saved and for one detached from a store it knows. The store is re-read after a pooled run, since the elements workers rewrote are newer than the ones the parent holds.
- Pool workers do **not** fork — fork deadlocks once the parent has touched the zarr store through dask, which happens as soon as a dataset is converted or read in the same session. Workers therefore re-import `__main__`, so scripts using `pool_size > 1` need an `if __name__ == "__main__":` guard, and `decay_func` must be picklable. `pool_size=1` skips multiprocessing entirely.

### CellTypeAssigner

Wraps a scanpy `AnnData` object for iterative hierarchical cell type annotation. The target cell-by-gene data comes from the sdata (`sdata` + `table_name`, where `generate_cxg_table` leaves it) or as an `adata` directly; `save_annotated_adata` stores the annotated version back as a table. There is no h5ad path in or out — the only reference to one left in the package is the URL `download_lung_dataset` fetches the public cellxgene reference from.


- `ref_levels` / `ann_levels`: column names in reference/target obs for each level of the cell type hierarchy
- Workflow: `get_celltypes()` → `get_clusters()` → `plot_raw_clusters()` → `assign_cluster_celltypes()` → `merge_target_adata()`
- Uses Wilcoxon rank-sum test via `sc.tl.rank_genes_groups` for marker gene identification

## Dependencies

`anndata`, `scanpy`, `numpy`, `pandas`, `opencv-python`, `scikit-image`, `matplotlib`, `seaborn`, `tqdm`, `parse`, `pathspec`

### DatasetFormatter (SupportFuncs)

Builds a `SpatialData` out of the SoftSeg loose-file layout — per-FOV transcript CSV, integer-labelled mask TIFF, optional raw image TIFF, addressed by `.format(fov)` path patterns, placed by a `fov_locs` mapping. This is for example and legacy datasets; data from a supported platform should use the standard `spatialdata_io` readers.

`softseg_to_spatialdata(...)` splits every element by FOV (`{fov}_image`, `{fov}_labels`, `{fov}_points`), gives each FOV its own coordinate system plus the shared `"global"` one, and records the z-correction policy (`z_offset`, `snap_z`, `valid_z`) in `attrs[SpatialDataHelpers.SOFTSEG_ATTRS]`. Pass `save_loc=` to write the store as it goes, which is what `SoftAssigner` then needs for parallel runs.

**Naming a FOV's coordinate system is this converter's business alone.** `DatasetFormatter._fov_coordinate_system` produces the `f"fov_{fov}"` name when stamping it onto new elements. Nothing that *reads* an object rebuilds that string: `SpatialDataHelpers._element_fov_cs(element)` recovers the name from the element's own transformations, by discarding `"global"`, the `"global_only_*"` systems and `STACK_3D_CS`. So an object built by a different reader — whose FOV systems are named anything at all — works unchanged.

### UnitTestWarper (SupportFuncs)

Turns the st-qc simulation object (shapes `cells`/`cell_borders`, points `transcripts`, table `counts`) into the layout `SoftAssigner` reads, so a simulated dataset can be fed straight through the pipeline. `UnitTestWarper(sdata, fov="0000").run(...)` warps the cell boundaries to stand in for imperfect segmentation, then emits:

- `labels[f"{fov}_labels"]` — the warped cells rasterized, using the SoftSeg convention that mask value `m` is cell id `m - 1`.
- `points[f"{fov}_points"]` — the transcripts in that mask's pixel space, 1-based, with the untouched simulation coordinates kept as `global_x`/`global_y`.

Both carry `fov_{fov}` + `"global"`, and the z policy goes into `attrs`. The ground truth (`cells_warped`, `cell_borders_warped`, `counts_warped`) stays alongside. Note the warped shapes are deliberately **not** named `{fov}_z{z}_shapes`: they are in global coordinates, so `get_cell_shapes` reusing them would measure distances in the wrong space — it contours the mask instead.

There is no `out_loc`: every element is saved into the object's own store as it is produced. A run consumes `transcripts`, so re-running (sweeping warp amplitude, say) rebuilds them from `global_x`/`global_y`, dropping any assignment columns a previous pass left behind since those were made against the old segmentation.

### Outputs live in the store

Nothing in the pipeline writes a side-car file next to the zarr. Results are elements: transcript columns on the points, cell-by-gene and delta tables in `tables`, label images in `labels`. `UnitTestWarper.run` follows the same rule — it emits the label image and transcripts as elements rather than as a `.tif` and `.csv` alongside a zarr.

That coordinate system is how transcript locations reach the label image's pixel grid: `rasterize` snaps its grid to whole pixels, so the grid origin is not exactly the `min_coordinate` it was asked for, and the old `(x - min_x) * scale**2` shift was off by a fraction of a pixel. Composing the transcripts' transform with the inverse of the raster's own `"global"` transform is exact, and it is carried by the object rather than by a separate file.

### SegImagePlotter (SupportFuncs)

Draws a FOV's segmentation over its raw image, one z-slice at a time, reading from the same layout `SoftAssigner` uses: `labels[f"{fov}_labels"]` and, when present, `images[f"{fov}_image"]`.

`SegImagePlotter(sdata, fov=None)` then `plot_subset(target_cell, highlight_cells, adata, highlight_type, single_channel, transcripts)`. A cell in `highlight_cells` is outlined red, one whose `adata.obs` row matches `highlight_type` white, everything else black; `target_cell` zooms to that cell's extent plus a 100px border, plots only the slices it appears on, and is outlined red itself — it is the cell being looked at, and it is already what a transcript's colour is measured against, so it is in focus for both.

`transcripts` draws individual transcripts over the segmentation, read from `points[f"{fov}_points"]`. Pass the name of an assignment column and what it means depends on whether anything is in focus: with a `target_cell` or `highlight_cells` it is **those cells' claim on the data** — every transcript either that column or `og_cell` places in them, plus every one they were a candidate for and lost, via `cell_transcripts` — and with nothing in focus it is the whole FOV's edits, via `changed_transcripts(assigned_col)`, which finds every transcript whose column differs from the `og_cell` the run started from, comparing as plain objects so a transcript only one of them placed is not lost to NA propagation. The scoping is the difference between a readable plot and one that looks broken: for one real cell, 162 transcripts belong to it and 1 of them was moved, so a zoomed plot of the unscoped reading draws 10 markers, 9 of them other cells'. A frame from either method is drawn as given — that is how to see a zoomed-to cell's *edits* rather than its claim — and a plain list of transcript ids works too. Each marker is coloured by where it stands relative to the cells in focus (`target_cell` plus `highlight_cells`): cyan for one that stayed in, green for one moved in, magenta for one moved out, grey for one a focus cell was in the running for and did not get, yellow for one that moved between cells that are not in focus, which is also what everything gets when nothing is in focus. `TRANSCRIPT_LABELS` names each of those in a legend below the axes — keyed on what the *slice* drew, so it only ever names colours that are on the plot in front of you: a slice holding nothing but the cell's own transcripts is not keyed for moves that happened two slices up, and a slice with no transcripts on it gets no legend at all. It follows that the legend changes between slices of one call. Below the axes because the crops are tight around a cell and a legend inside one would cover it. Only the transcripts on the slice being drawn and inside the crop appear on it.

`changed_transcripts` is a run's *edits*, which for a single cell is typically one or two transcripts — the step only moves what was ambiguous. `cell_transcripts(cells, assigned_col=None, og_col="og_cell", candidates=True)` is the cell's *claim*: every transcript either column places there, **and every one the cell was in the running for**. A cell is in the running for a transcript when it appears in that transcript's `cell_ids` map — the set `blur_fov` scored it against and the set `evaluate_overlapping_regions` chose from. The ones it did not get are the reason it has the ones it did, so they belong on the same plot; they come back flagged in a `considered` column, which is what `transcript_groups` colours grey. `og_col` is a default rather than something the caller asked for, so a store that never recorded it reads the one assignment it does have; a named `assigned_col` that is absent is an error.

`_considered_by` is the lookup. There are hundreds of thousands of `cell_ids` strings per FOV and parsing all of them would dominate the plot, so a substring test over the raw column narrows it first — an id appears in the text of any map holding it, quoted keys or bare — and only the survivors are parsed, which settles the over-matches the substring test lets through. For one cell of a 391k-transcript FOV that is ~0.5s.

Which slice a transcript is drawn on is the slice it was *assigned* on — `valid_slices`/`_slice_of` apply the same `valid_z`/`snap_z` policy from `sdata.attrs` that `SoftAssigner.transcript_slices` does, and a 2D FOV puts everything on slice 0. Rounding the raw `z` instead silently disagrees with the run being drawn: in a 2D FOV whose transcripts carry any non-zero z, every marker lands on a slice that does not exist and nothing is drawn at all.

The rest — a transcript on no segmented slice, on a slice the zoom does not cover, or outside the crop — is counted up in a warning once the last slice is drawn, because a plot that dropped them looks exactly like one with nothing to draw. Zooming to a typical cell is that case: the changed transcripts of a whole FOV number in the thousands but only a handful sit on the cell being looked at.

Transcript markers are drawn with a plain `ax.scatter` on the axes `pl.show` hands back (`_draw_transcripts`), not through `render_points`. That path builds an AnnData per call to reach scanpy's colouring, and doing so warns twice over — a deprecated `dtype=`, and an integer index anndata rewrites as strings — before matplotlib warns again that the `cmap`/`norm` it always passes have nothing to colour-map. Three warnings per call, six calls a plot, and none of them mean anything here: the colours are already decided, one per group, and a scatter takes them directly. The markers are already in the crop's display space, which is the space `pl.show` leaves the axes in, so they need no transform.

A transcript at `(x, y)` sits at mask array position `[y - 1, x - 1]` and array cell `i` spans `[i, i + 1]`, so the marker lands half a pixel in, shifted by where the crop window starts — the same half-pixel `_cell_polygons` applies, which is what puts a cell's transcripts inside its outline.

Rendering goes through `spatialdata_plot`: each slice becomes a small 2D `SpatialData` holding the cropped image and the slice's cells, and `render_images(channel=single_channel)` puts the image underneath. `spatialdata-plot` is imported lazily and lives in the `plotting` extra, so the rest of the package does not depend on it.

The cells are drawn as **shapes, one polygon per cell** (`_cell_polygons`), not as labels. `render_labels` colours by category, so every cell sharing a colour is one region to it and two neighbours that touch come out as a single ring around the pair with no border between them — the merged boundary. A polygon per cell is a polygon per cell however they are coloured, so each keeps its own closed outline. They are contoured with the same `SpatialDataHelpers._slice_to_polygons` the pipeline uses, so the ring drawn is the boundary transcripts were measured against — it runs through the centres of the boundary pixels, which is why a polygon covers ~90% of its cell's pixels rather than all of them. Each cell is contoured inside its own `find_objects` bounding box, which is what makes this affordable on a full FOV (~900 cells in ~1s). One shapes element per outline group, rendered in `OUTLINE_COLORS` order so a highlighted cell's ring is never overdrawn by a neighbour's.

`pl.show` is called with `return_ax=True, show=False` so the legend can go on and the axes can be pinned to the crop before the figure is drawn — pinning them matters because with no image the shapes alone would set the extent, and every slice would be framed differently. It also means one figure per slice instead of the two `pl.show`'s own `plt.show()` used to produce.

`CONTOUR_PX = 1` is the outline width, a `render_shapes` line width — thin, so two neighbours' rings stay legible as two rather than running together into a band. `TRANSCRIPT_PX = 20` is the marker size and `TRANSCRIPT_EDGE_PX = 0.8` the dark edge around it: the microscopy underneath is red/green/blue everywhere, so a marker needs contrast it carries itself rather than a colour that happens to differ from whatever it lands on. Both are sized for a cell's worth of transcripts — a few dozen on a slice — not for the handful a run moved.

### AssignmentComparer (SupportFuncs)

Compares two assignments of the same transcripts. `AssignmentComparer(sdata, "left_col", "right_col")` reads both columns from one object; `right_sdata=` reads the second from another, which is how a pre-refactor run is compared against a current one. `sel_fovs=` narrows the comparison, defaulting to every FOV both sides carry their column for. It never writes — given a path or object it builds a `SoftAssigner(save_to_disk=False)`, and an assigner you already have is used as-is.

`summary()` returns every metric as a dict, `per_fov()` the same per FOV, `report()` a few printable lines. The metrics fall in three groups:

- **agreement** — how many transcripts each side placed, how often in the same cell, and `adjusted_rand_index`, which asks whether the two agree on *which transcripts belong together* regardless of what the cells are called (so it is meaningful between runs that numbered cells differently). The module-level `adjusted_rand_index` computes it from a contingency table rather than through scikit-learn, which is an optional dependency here.
- **movement** — of the transcripts each side moved off the original segmentation (`og_col`, default `og_cell`), how much those two sets overlap and how often the two agree on where a moved transcript went. Skipped when the column is absent.
- **composition** — `cell_by_gene(side)` tallies a cell-by-gene matrix straight from the transcripts, so it needs no segmentation and works against a faked sdata. `cxg_jaccard()` compares the two over the union of their cells and genes, both as `binary` (which (cell, gene) pairs have any count) and `weighted` (sum(min)/sum(max), so how much of the total signal is placed identically). `per_cell()` breaks that down per cell alongside the Jaccard of each cell's transcript set.

`disagreements()` hands back the rows behind `n_disagree`.

**Streaming.** Every metric folds the FOVs in one at a time through `_CompareTally` rather than working over one big table: `iter_frames()` builds a FOV's frame, hands it over and drops it before reading the next. `summary()`, `per_fov()`, `cxg_jaccard()`, `per_cell()`, `cell_by_gene()`, `disagreements()` and `candidate_agreement()` all work this way, so what they cost follows the largest single FOV and the size of the answer rather than the number of FOVs. Measured over the same FOVs both ways: 2 FOVs +1.40GB streamed against +1.61 gathered, 4 FOVs +1.39 against +1.86, 8 FOVs +4.87 against +6.35 — the streamed figure tracks the biggest FOV in the set, the gathered one tracks the sum.

The arithmetic is exact, not approximate. Every metric is either a count, which adds, or comes from a table whose size follows the *result* rather than the data: the contingency of (left cell, right cell) pairings behind the Rand index (`adjusted_rand_index_from_pairs`), the set of cells each side used, and the two cell-by-gene tallies. The median per-cell Jaccard is the one thing that does not add, and it does not need to — it is computed at the end from the accumulated per-cell counts. A streamed run and a gathered one over the same FOVs give bit-identical numbers, which is worth re-checking after any change here.

`stream` is automatic: on when either side holds one FOV at a time, off otherwise, and overridable. `transcripts()` is the one method that still holds everything, kept for looking at rows over a few FOVs; in streaming mode it does not cache, since keeping it is what streaming is avoiding.

Comparisons run on plain object arrays rather than on the nullable columns themselves: `!=` between them propagates NA, which would drop a transcript one side placed and the other did not out of the comparison instead of counting it as a difference.

### LegacyRunLoader (SupportFuncs)

Fakes a `SpatialData` out of a pre-refactor run's `complete_loc` directory, so an old result can go through `AssignmentComparer` or any `SoftAssigner` step that only needs transcripts. `LegacyRunLoader(complete_loc).to_sdata(sel_fovs=None)` reads:

- `fov_{fov}_cellids.csv` → `points[f"{fov}_points"]`, keeping every column the old run wrote (`cell_ids`, the assignment columns, `og_cell`/`og_type`). The transcript id arrives as the frame's unnamed index and is restored as the `index` column; `z` is taken from `global_z`, which is what the old code indexed mask slices with.
- `overlap_eval_{col}_fov_{fov}.pydict` → the `assigned_trs_{col}` table, in the shape `evaluate_overlapping_regions_single_fov` writes now.
- `*.h5ad` → tables named by file stem, but only when asked: `load_tables` is False by default, since each file is a whole cell-by-gene matrix (26 files, 19GB, in one real output directory) and a comparison needs none of them. True reads all; a name or list of names reads those, matched against the stem or as a glob. `h5ad_files()` lists what is there.

The `assigned_trs_{col}` tables are named *after* the column they record, not instead of it. To compare an assignment, pass `AssignmentComparer` the column (`"thresh5_min0.7"`) rather than the table (`"assigned_trs_thresh5_min0.7"`); `assignment_columns(fov)` lists the columns from the CSV header alone. Naming a table where a column belongs is the mistake the comparer's error message calls out by name.

The result is in memory and never written; there are no labels or images in it, so steps that read a segmentation are not available. `delta_tallies_*.pydict` files hold the assignments rather than the tallies — the code that wrote them passed the wrong variable — so they are read back as what they contain, under a `{col}_delta_tallies` name.

**One FOV at a time.** `to_sdata()` over a whole run reads every CSV and keeps them all — 294 files and 57GB in one real directory, which does not fit anywhere. `loader.streaming()` returns a `LegacyFovView` instead: it offers `AssignmentComparer` the surface an assigner has, but builds the assigner for a FOV when asked and drops the one before, so the directory is visited rather than gathered. `fov_sdata(fov)` is the single FOV on its own if you want it directly. Handing `AssignmentComparer` the *loader* does this for you — it takes the streaming view, since reading a run a FOV at a time is the only way that scales.

What the comparison asks *about* the data — which FOVs exist, which carry a column — is answered from the CSV headers alone (`columns`, `has_column`, both cached), so choosing what to compare reads no rows. That matters: resolving FOVs used to mean loading each one to look at it.
